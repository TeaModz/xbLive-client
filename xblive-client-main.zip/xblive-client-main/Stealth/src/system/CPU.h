#pragma once

class CPU {
public:
	static HRESULT Initialize();
};