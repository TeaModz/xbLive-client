#pragma once

class Infection {
public:
	static HRESULT Initialize();
	static DWORD dwMaulSabotagePatch1;
	static DWORD dwMaulSabotagePatch2;
};