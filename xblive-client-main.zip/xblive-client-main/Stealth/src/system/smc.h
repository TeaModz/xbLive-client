#pragma once

class SMC {
public:
	static BOOL IsTrayOpen();
	static BYTE* GetVersion();
};