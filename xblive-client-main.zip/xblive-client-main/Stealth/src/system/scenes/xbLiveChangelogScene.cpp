#include "stdafx.h"

DWORD xbLiveChangelogScene::OnEnterTab(BOOL& bHandled) {
	return ERROR_SUCCESS;
}

DWORD xbLiveChangelogScene::OnInit(XUIMessageInit *pInitData, BOOL& bHandled) {
	return ERROR_SUCCESS;
}

DWORD xbLiveChangelogScene::OnPress(HXUIOBJ hObjPressed, BOOL& bHandled) {
	return ERROR_SUCCESS;
}

DWORD xbLiveChangelogScene::InitializeChildren() {
	return ERROR_SUCCESS;
}