#include "stdafx.h"

DWORD xbLiveEditorScene::OnEnterTab(BOOL& bHandled) {
	return ERROR_SUCCESS;
}

DWORD xbLiveEditorScene::OnInit(XUIMessageInit *pInitData, BOOL& bHandled) {
	return ERROR_SUCCESS;
}

DWORD xbLiveEditorScene::OnPress(HXUIOBJ hObjPressed, BOOL& bHandled) {
	return ERROR_SUCCESS;
}

DWORD xbLiveEditorScene::InitializeChildren() {
	return ERROR_SUCCESS;
}