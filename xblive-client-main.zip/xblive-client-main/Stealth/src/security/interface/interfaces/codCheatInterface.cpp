#include "stdafx.h"

NativeRegistration* CodCheat::GetRegistration() {
	return pInvoker.GetTable();
}