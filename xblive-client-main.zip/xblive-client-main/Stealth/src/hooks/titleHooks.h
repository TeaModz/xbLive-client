#pragma once

class TitleHooks {
public:
	static void RunOnTitleLoad(PLDR_DATA_TABLE_ENTRY moduleHandle);
};