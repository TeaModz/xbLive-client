#pragma once

BYTE* loadFileToBuf(char* fname, PDWORD len);
BYTE* loadFileToBuf(WCHAR* fname, PDWORD len);
